package myau.ui.clickgui;

import myau.Myau;
import myau.module.Module;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class SoraClickGUI extends GuiScreen {
    public static final Color PINK      = new Color(0xFF66AA);
    public static final Color DARK_BG   = new Color(18, 10, 20, 220);
    public static final Color CARD_BG   = new Color(22, 10, 18, 220);
    public static final Color TEXT      = new Color(255, 229, 240);
    public static final Color TEXT_DIM  = new Color(184, 144, 158);

    private final List<CategoryPanel> categories = new ArrayList<>();
    private final File configFile = new File(Myau.configDir, "sora_gui.cfg");

    private float scaleProgress = 0.0f;
    private boolean closing = false;

    // ===== 通知系统 =====
    private static final List<Notification> notifications = new ArrayList<>();

    public static void addNotification(String text) {
        notifications.add(new Notification(text));
    }

    private static class Notification {
        String text;
        long startTime;
        Notification(String text) {
            this.text = text;
            this.startTime = System.currentTimeMillis();
        }
        boolean isExpired() {
            return System.currentTimeMillis() - startTime > 1500;
        }
    }

    public SoraClickGUI() {
        categories.add(new CategoryPanel("Combat",   Myau.moduleManager.getModulesInCategory(Module.Category.COMBAT)));
        categories.add(new CategoryPanel("Movement", Myau.moduleManager.getModulesInCategory(Module.Category.MOVEMENT)));
        categories.add(new CategoryPanel("Player",   Myau.moduleManager.getModulesInCategory(Module.Category.PLAYER)));
        categories.add(new CategoryPanel("Visual",   Myau.moduleManager.getModulesInCategory(Module.Category.VISUAL)));
        categories.add(new CategoryPanel("Misc",     Myau.moduleManager.getModulesInCategory(Module.Category.MISC)));

        int y = 20;
        for (CategoryPanel cat : categories) {
            cat.setX(10);
            cat.setY(y);
            y += 18;
        }
        loadPositions();
    }

    @Override
    public void initGui() {
        closing = false;
    }

    @Override
    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        // 动画
        if (closing) {
            scaleProgress -= 0.08f;
            if (scaleProgress <= 0) {
                mc.displayGuiScreen(null);
                return;
            }
        } else {
            scaleProgress += 0.08f;
            if (scaleProgress > 1) scaleProgress = 1;
        }

        float scale = 0.3f + scaleProgress * 0.7f;
        int alpha = (int)(scaleProgress * 100);

        drawRect(0, 0, width, height, new Color(0, 0, 0, alpha).getRGB());

        ScaledResolution sr = new ScaledResolution(mc);
        GL11.glPushMatrix();
        float centerX = sr.getScaledWidth() / 2f;
        float centerY = sr.getScaledHeight() / 2f;
        GL11.glTranslatef(centerX, centerY, 0);
        GL11.glScalef(scale, scale, 1);
        GL11.glTranslatef(-centerX, -centerY, 0);

        for (CategoryPanel cat : categories) {
            cat.setAnimProgress(scaleProgress);
            cat.draw(mc.fontRendererObj, mouseX, mouseY);
            cat.updateDrag(mouseX, mouseY);
        }

        GL11.glPopMatrix();

        // 底部水印
        int textColor = new Color(255, 102, 170, (int)(scaleProgress * 255)).getRGB();
        mc.fontRendererObj.drawStringWithShadow("Sora", 4, height - 12, textColor);

        // ===== 绘制通知 =====
        Iterator<Notification> it = notifications.iterator();
        while (it.hasNext()) {
            Notification n = it.next();
            if (n.isExpired()) {
                it.remove();
                continue;
            }
            long elapsed = System.currentTimeMillis() - n.startTime;
            float progress = Math.min(1, elapsed / 300f); // 淡入时间
            float fadeOut = 1;
            if (elapsed > 1200) {
                fadeOut = 1 - (elapsed - 1200) / 300f; // 淡出
            }
            int noteAlpha = (int)(255 * progress * fadeOut);
            if (noteAlpha > 255) noteAlpha = 255;
            if (noteAlpha < 0) noteAlpha = 0;

            Color bgColor = new Color(20, 10, 24, (int)(200 * progress * fadeOut));
            Color borderColor = new Color(255, 102, 170, noteAlpha);
            Color fontColor = new Color(255, 204, 221, noteAlpha);

            int noteX = sr.getScaledWidth() - 160;
            int noteY = sr.getScaledHeight() - 60;
            int noteW = 150;
            int noteH = 30;

            Gui.drawRect(noteX, noteY, noteX + noteW, noteY + noteH, bgColor.getRGB());
            Gui.drawRect(noteX, noteY, noteX + noteW, noteY + 1, borderColor.getRGB());
            Gui.drawRect(noteX, noteY + noteH - 1, noteX + noteW, noteY + noteH, borderColor.getRGB());

            mc.fontRendererObj.drawStringWithShadow(n.text, noteX + 8, noteY + 10, fontColor.getRGB());
        }

        // 滚轮
        int wheel = Mouse.getDWheel();
        if (wheel != 0) {
            for (CategoryPanel cat : categories) {
                cat.onScroll(wheel > 0 ? 1 : -1);
            }
        }
    }

    // ... 其余方法（mouseClicked, mouseReleased, keyTyped, onGuiClosed, doesGuiPauseGame, savePositions, loadPositions）与上一版保持一致
}