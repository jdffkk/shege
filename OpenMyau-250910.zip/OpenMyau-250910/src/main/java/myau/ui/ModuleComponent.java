public void mouseClicked(int mouseX, int mouseY, int button) {
    if (button == 0 && isHovered(mouseX, mouseY)) {
        if (mouseX >= x + width - 18) {
            module.toggle();
            mc.thePlayer.playSound("random.click", 0.5f, 1.0f);
            SoraClickGUI.addNotification(module.getName() + (module.isEnabled() ? " §aON" : " §cOFF"));
        } else {
            expanded = !expanded;
        }
    }
    if (expanded) {
        for (SettingComponent sc : settings) {
            sc.mouseClicked(mouseX, mouseY, button);
        }
    }
}