package myau.ui.clickgui;

import myau.module.Module;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class CategoryPanel {
    private final String name;
    private final List<ModuleComponent> modules = new ArrayList<>();
    private int x, y;
    private boolean open = false;
    private boolean dragging = false;
    private int dragX, dragY;
    private int scrollOffset = 0;
    private float animProgress = 1.0f;

    public CategoryPanel(String name, List<Module> mods) {
        this.name = name;
        for (Module m : mods) {
            modules.add(new ModuleComponent(m, this));
        }
    }

    public void setAnimProgress(float p) {
        this.animProgress = p;
        for (int i = 0; i < modules.size(); i++) {
            float delay = i * 0.05f;
            modules.get(i).setAnimProgress(Math.max(0, Math.min(1, (p - delay) / 0.5f)));
        }
    }

    public void draw(FontRenderer fr, int mouseX, int mouseY) {
        int offsetX = (int)((1 - animProgress) * -30);
        int bg = open ? new Color(30, 12, 22, 230).getRGB() : new Color(20, 8, 14, 200).getRGB();
        Gui.drawRect(x + offsetX, y, x + 80 + offsetX, y + 16, bg);
        Gui.drawRect(x + offsetX, y, x + 80 + offsetX, y + 1, SoraClickGUI.PINK.getRGB());
        Gui.drawRect(x + offsetX, y + 15, x + 80 + offsetX, y + 16, SoraClickGUI.PINK.getRGB());
        fr.drawString((open ? "▼ " : "▶ ") + name, x + 4 + offsetX, y + 4, SoraClickGUI.TEXT.getRGB());

        if (open) {
            int modX = x + 85 + offsetX;
            int modY = y - scrollOffset;
            for (ModuleComponent mod : modules) {
                mod.setX(modX);
                mod.setY(modY);
                mod.draw(fr, mouseX, mouseY);
                modY += mod.getTotalHeight() + 2;
            }
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (button == 0 && mouseX >= x && mouseX <= x + 80 && mouseY >= y && mouseY <= y + 16) {
            if (mouseX <= x + 65) {
                open = !open;
            } else {
                dragging = true;
                dragX = mouseX - x;
                dragY = mouseY - y;
            }
        }
        if (open) {
            for (ModuleComponent mod : modules) {
                mod.mouseClicked(mouseX, mouseY, button);
            }
        }
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = false;
        if (open) {
            for (ModuleComponent mod : modules) {
                mod.mouseReleased(mouseX, mouseY, state);
            }
        }
    }

    public void onScroll(int direction) {
        if (open) scrollOffset = Math.max(0, scrollOffset + direction * 10);
    }

    public void updateDrag(int mouseX, int mouseY) {
        if (dragging) {
            x = mouseX - dragX;
            y = mouseY - dragY;
        }
    }

    public String getName() { return name; }
    public int getX() { return x; }
    public void setX(int x) { this.x = x; }
    public int getY() { return y; }
    public void setY(int y) { this.y = y; }
    public boolean isOpen() { return open; }
    public void setOpen(boolean open) { this.open = open; }
}