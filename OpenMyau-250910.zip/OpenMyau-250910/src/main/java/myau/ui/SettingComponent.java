package myau.ui.clickgui;

import myau.module.Setting;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import java.awt.*;

public class SettingComponent {
    public final Setting setting;
    public int x, y, height = 12;
    private boolean dragging = false;

    public SettingComponent(Setting setting) {
        this.setting = setting;
    }

    public void draw(FontRenderer fr, int mouseX, int mouseY) {
        if (setting instanceof Setting.Slider) {
            drawSlider(fr, mouseX, mouseY);
        } else if (setting instanceof Setting.Mode) {
            drawMode(fr);
        }
    }

    public void mouseClicked(int mouseX, int mouseY, int button) {
        if (setting instanceof Setting.Slider) {
            if (button == 0 && mouseX >= x && mouseX <= x + 50 && mouseY >= y && mouseY <= y + height) {
                dragging = true;
            }
        } else if (setting instanceof Setting.Mode) {
            if (button == 0 && mouseX >= x && mouseX <= x + 60 && mouseY >= y && mouseY <= y + height) {
                ((Setting.Mode) setting).next();
            }
        }
    }

    public void mouseReleased(int mouseX, int mouseY, int state) {
        dragging = false;
    }

    private void drawSlider(FontRenderer fr, int mouseX, int mouseY) {
        Setting.Slider s = (Setting.Slider) setting;
        int sw = 50;
        Gui.drawRect(x, y, x + sw, y + height, new Color(42, 26, 38).getRGB());
        double pct = (s.getValue() - s.getMin()) / (s.getMax() - s.getMin());
        Gui.drawRect(x, y, x + (int)(sw * pct), y + height, SoraClickGUI.PINK.getRGB());
        fr.drawString(s.getName() + ": " + Math.round(s.getValue() * 10) / 10.0, x + sw + 4, y + 1, -1);
        if (dragging) {
            double newPct = Math.max(0, Math.min(1, (mouseX - x) / 50.0));
            s.setValue(s.getMin() + (s.getMax() - s.getMin()) * newPct);
        }
    }

    private void drawMode(FontRenderer fr) {
        Setting.Mode m = (Setting.Mode) setting;
        fr.drawString(m.getName() + ": " + m.getValue(), x, y + 1, -1);
    }
}