package myau.module.modules;

import myau.module.Module;
import myau.ui.clickgui.SoraClickGUI;
import net.minecraft.client.Minecraft;
import org.lwjgl.input.Keyboard;

public class ClickGUIModule extends Module {
    public ClickGUIModule() {
        super("ClickGUI", Category.MISC);
        setKey(Keyboard.KEY_RSHIFT);
    }

    @Override
    public void onEnable() {
        Minecraft.getMinecraft().displayGuiScreen(new SoraClickGUI());
        setEnabled(false);
    }
}